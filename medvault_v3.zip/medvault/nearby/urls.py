from django.urls import path

from . import views

urlpatterns = [
    path("patient/nearby/", views.nearby_page, name="nearby"),
    path("patient/nearby/search/", views.nearby_search, name="nearby_search"),
]
