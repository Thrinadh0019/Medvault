from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render

from accounts.decorators import patient_required

from . import services


@patient_required
def nearby_page(request):
    return render(request, "nearby/nearby.html", {
        "places_enabled": services.configured(),
        "maps_key": settings.GOOGLE_MAPS_BROWSER_KEY,
        "map_id": settings.GOOGLE_MAP_ID,
        "default_radius": settings.NEARBY_RADIUS_M // 1000,
    })


@patient_required
def nearby_search(request):
    """JSON API used by the Nearby page. Your location is used for this request only and is not stored."""
    if not services.configured():
        return JsonResponse({"error": "Place search is not configured yet."}, status=503)
    kind = request.GET.get("kind", "lab")
    if kind not in services.KINDS:
        return JsonResponse({"error": "Unknown place type."}, status=400)

    q = request.GET.get("q", "").strip()[:100]
    try:
        if q:
            results = services.search_text(q, kind)
        else:
            lat, lng = float(request.GET["lat"]), float(request.GET["lng"])
            if not (-90 <= lat <= 90 and -180 <= lng <= 180):
                raise ValueError
            radius = min(max(int(request.GET.get("radius", settings.NEARBY_RADIUS_M)), 500), 20000)
            results = services.search_nearby(lat, lng, kind, radius)
    except (KeyError, ValueError):
        return JsonResponse({"error": "Share your location or type an area name."}, status=400)
    except services.PlacesError as exc:
        return JsonResponse({"error": str(exc)}, status=502)
    return JsonResponse({"results": results})
