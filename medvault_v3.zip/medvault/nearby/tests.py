from unittest import mock

from django.test import TestCase, override_settings

from accounts.models import User
from nearby import services

FAKE = {"places": [
    {"id": "far", "displayName": {"text": "Far Lab"}, "formattedAddress": "Far St",
     "location": {"latitude": 17.45, "longitude": 78.60}, "rating": 4.1, "userRatingCount": 12},
    {"id": "near", "displayName": {"text": "Near Lab"}, "formattedAddress": "Near St",
     "location": {"latitude": 17.401, "longitude": 78.501}, "rating": 4.6, "userRatingCount": 340,
     "currentOpeningHours": {"openNow": True}, "nationalPhoneNumber": "040 1234 5678",
     "googleMapsUri": "https://maps.google.com/?cid=1"},
]}


@override_settings(GOOGLE_PLACES_API_KEY="test-key")
class NearbyTests(TestCase):
    def setUp(self):
        self.pat = User.objects.create_user("9876543210", "pass12345X", first_name="Asha")
        self.doc = User.objects.create_user("9000000001", "pass12345X", role="doctor", first_name="Dr", is_verified=True)

    def login_patient(self):
        self.client.post("/patient/login/", {"phone": "9876543210", "password": "pass12345X"})

    def test_results_sorted_by_distance_with_links(self):
        self.login_patient()
        with mock.patch.object(services, "_request", return_value=FAKE) as m:
            r = self.client.get("/patient/nearby/search/", {"kind": "lab", "lat": "17.40", "lng": "78.50"})
        data = r.json()["results"]
        self.assertEqual([p["name"] for p in data], ["Near Lab", "Far Lab"])
        self.assertLess(data[0]["distance_km"], 0.5)
        self.assertIn("destination_place_id=near", data[0]["directions_url"])
        self.assertTrue(data[0]["open_now"])
        method, body = m.call_args[0]
        self.assertEqual(method, "searchNearby")
        self.assertEqual(body["includedTypes"], ["medical_lab"])

    def test_hospital_and_area_text_search(self):
        self.login_patient()
        with mock.patch.object(services, "_request", return_value=FAKE) as m:
            r = self.client.get("/patient/nearby/search/", {"kind": "hospital", "q": "Uppal, Hyderabad"})
        self.assertEqual(len(r.json()["results"]), 2)
        self.assertEqual(m.call_args[0][0], "searchText")
        self.assertIn("hospital in Uppal, Hyderabad", m.call_args[0][1]["textQuery"])

    def test_validation_and_errors(self):
        self.login_patient()
        self.assertEqual(self.client.get("/patient/nearby/search/", {"kind": "lab"}).status_code, 400)
        self.assertEqual(self.client.get("/patient/nearby/search/", {"kind": "lab", "lat": "999", "lng": "1"}).status_code, 400)
        self.assertEqual(self.client.get("/patient/nearby/search/", {"kind": "bar", "q": "x"}).status_code, 400)
        with mock.patch.object(services, "_request", side_effect=services.PlacesError("boom")):
            r = self.client.get("/patient/nearby/search/", {"kind": "lab", "q": "x"})
        self.assertEqual(r.status_code, 502)

    @override_settings(GOOGLE_PLACES_API_KEY="")
    def test_not_configured_still_renders_page(self):
        self.login_patient()
        self.assertEqual(self.client.get("/patient/nearby/search/", {"kind": "lab", "q": "x"}).status_code, 503)
        self.assertContains(self.client.get("/patient/nearby/"), 'data-places="0"')

    def test_patients_only(self):
        self.assertEqual(self.client.get("/patient/nearby/").status_code, 302)       # anonymous
        self.client.post("/doctor/login/", {"phone": "9000000001", "password": "pass12345X"})
        self.assertEqual(self.client.get("/patient/nearby/").status_code, 302)       # doctor
        self.assertEqual(self.client.get("/patient/nearby/search/", {"kind": "lab", "q": "x"}).status_code, 302)

    def test_browser_key_never_equals_server_key_in_page(self):
        self.login_patient()
        with override_settings(GOOGLE_MAPS_BROWSER_KEY="browser-key"):
            html = self.client.get("/patient/nearby/").content.decode()
        self.assertIn("browser-key", html); self.assertNotIn("test-key", html)
