"""Google Places API (New) helpers. The API key stays on the server."""
import json
import logging
import math
import urllib.error
import urllib.request

from django.conf import settings

log = logging.getLogger(__name__)

KINDS = {
    "lab": {"type": "medical_lab", "text": "diagnostic laboratory"},
    "hospital": {"type": "hospital", "text": "hospital"},
}
BASE = "https://places.googleapis.com/v1/places:"
CORE_FIELDS = ["id", "displayName", "formattedAddress", "location", "googleMapsUri", "primaryTypeDisplayName"]
DETAIL_FIELDS = ["rating", "userRatingCount", "currentOpeningHours.openNow", "nationalPhoneNumber"]


class PlacesError(Exception):
    pass


def configured():
    return bool(settings.GOOGLE_PLACES_API_KEY)


def _field_mask():
    fields = CORE_FIELDS + (DETAIL_FIELDS if settings.PLACES_INCLUDE_DETAILS else [])
    return ",".join(f"places.{f}" for f in fields)


def _request(method, body):
    """POST to Google. Kept separate so tests can replace it."""
    req = urllib.request.Request(
        BASE + method, data=json.dumps(body).encode(), method="POST",
        headers={
            "Content-Type": "application/json",
            "X-Goog-Api-Key": settings.GOOGLE_PLACES_API_KEY,
            "X-Goog-FieldMask": _field_mask(),
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        log.warning("Places API HTTP %s: %s", exc.code, exc.read()[:300])
        raise PlacesError("Google Places rejected the request. Check the API key and that Places API (New) is enabled.") from exc
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        raise PlacesError("Could not reach Google Places. Please try again.") from exc


def haversine_km(lat1, lng1, lat2, lng2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 6371 * 2 * math.asin(math.sqrt(a))


def _clean(places, origin):
    out = []
    for p in places or []:
        loc = p.get("location") or {}
        lat, lng = loc.get("latitude"), loc.get("longitude")
        if lat is None or lng is None:
            continue
        item = {
            "id": p.get("id", ""),
            "name": (p.get("displayName") or {}).get("text", "Unnamed place"),
            "address": p.get("formattedAddress", ""),
            "lat": lat, "lng": lng,
            "type": (p.get("primaryTypeDisplayName") or {}).get("text", ""),
            "rating": p.get("rating"),
            "rating_count": p.get("userRatingCount"),
            "open_now": (p.get("currentOpeningHours") or {}).get("openNow"),
            "phone": p.get("nationalPhoneNumber", ""),
            "maps_url": p.get("googleMapsUri", ""),
            "distance_km": None,
        }
        item["directions_url"] = (
            f"https://www.google.com/maps/dir/?api=1&destination={lat},{lng}"
            + (f"&destination_place_id={item['id']}" if item["id"] else "")
        )
        if origin:
            item["distance_km"] = round(haversine_km(origin[0], origin[1], lat, lng), 1)
        out.append(item)
    if origin:
        out.sort(key=lambda x: x["distance_km"])
    return out


def search_nearby(lat, lng, kind, radius_m):
    body = {
        "includedTypes": [KINDS[kind]["type"]],
        "maxResultCount": 20,
        "rankPreference": "DISTANCE",
        "languageCode": "en",
        "locationRestriction": {"circle": {"center": {"latitude": lat, "longitude": lng}, "radius": float(radius_m)}},
    }
    return _clean(_request("searchNearby", body).get("places"), (lat, lng))


def search_text(query, kind):
    body = {
        "textQuery": f"{KINDS[kind]['text']} in {query}",
        "maxResultCount": 20,
        "languageCode": "en",
        "regionCode": settings.PLACES_REGION,
    }
    return _clean(_request("searchText", body).get("places"), None)
