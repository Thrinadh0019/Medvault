from django.urls import path

from . import views

urlpatterns = [
    path("doctor/plans/", views.plans, name="plans"),
    path("doctor/plans/checkout/", views.checkout, name="checkout"),
    path("doctor/plans/verify/", views.verify, name="verify_payment"),
    path("doctor/plans/demo-pay/<str:pk>/", views.demo_pay, name="demo_pay"),
    path("doctor/invoice/<str:pk>/", views.invoice, name="invoice"),
]
