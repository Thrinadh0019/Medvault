from .services import get_plan


def plan_context(request):
    """Makes `current_plan` available in every template for doctors/labs."""
    u = getattr(request, "user", None)
    if u is not None and u.is_authenticated and u.role == "doctor":
        return {"current_plan": get_plan(u)}
    return {}
