import hashlib
import hmac
import tempfile
from datetime import timedelta
from unittest import mock

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TransactionTestCase, override_settings
from django.utils import timezone

from accounts.models import User
from billing import razorpay
from billing.models import Payment, Subscription
from billing.plans import PLANS
from billing.services import get_plan
from reports.models import AccessLog, Report

TMP = tempfile.mkdtemp()


def pdf(name="a.pdf"):
    return SimpleUploadedFile(name, b"%PDF-1.4 x", content_type="application/pdf")


@override_settings(MEDIA_ROOT=TMP, PAYMENTS_DEMO_MODE=True, RAZORPAY_KEY_ID="", RAZORPAY_KEY_SECRET="")
class BillingTests(TransactionTestCase):
    def setUp(self):
        self.doc = User.objects.create_user("9000000001", "pass12345X", role="doctor",
                                            first_name="Dr A", is_verified=True)
        self.client.post("/doctor/login/", {"phone": "9000000001", "password": "pass12345X"})

    def _seed_reports(self, n):
        for i in range(n):
            Report.objects.create(patient_phone="9876543210", original_name=f"r{i}.pdf", file="x",
                                  uploaded_by=self.doc)

    def test_free_plan_upload_limit_and_single_file(self):
        self._seed_reports(19)
        r = self.client.post("/doctor/upload/", {"patient_phone": "9876543210", "files": [pdf("a.pdf"), pdf("b.pdf")]})
        self.assertContains(r, "allows 1 file")                      # free = 1 file per upload
        self.assertEqual(self.client.post("/doctor/upload/", {"patient_phone": "9876543210", "files": pdf()}).status_code, 302)
        self.assertEqual(Report.objects.count(), 20)
        r = self.client.post("/doctor/upload/", {"patient_phone": "9876543210", "files": pdf("c.pdf")})
        self.assertContains(r, "upload limit reached")               # 21st blocked
        self.assertEqual(Report.objects.count(), 20)

    def test_demo_purchase_activates_pro_and_unlocks_bulk(self):
        r = self.client.post("/doctor/plans/checkout/", {"plan": "pro", "cycle": "monthly"})
        self.assertContains(r, "Simulate payment")
        pay = Payment.objects.get()
        self.assertEqual((pay.base_amount, pay.gst_amount, pay.total_amount), (49900, 8982, 58882))
        self.client.post(f"/doctor/plans/demo-pay/{pay.pk}/")
        self.assertEqual(get_plan(self.doc).key, "pro")
        pay.refresh_from_db()
        self.assertEqual(pay.status, "paid"); self.assertTrue(pay.invoice_no)
        # bulk upload now allowed + badge stored
        self.client.post("/doctor/upload/", {"patient_phone": "9876543210", "files": [pdf("a.pdf"), pdf("b.pdf"), pdf("c.pdf")]})
        self.assertEqual(Report.objects.count(), 3)
        self.assertEqual(Report.objects.first().uploader_badge, "Pro")
        # invoice opens for owner
        self.assertContains(self.client.get(f"/doctor/invoice/{pay.pk}/"), pay.invoice_no)
        # paying twice for the same order does not extend twice
        exp = Subscription.objects.get().expires_at
        self.client.post(f"/doctor/plans/demo-pay/{pay.pk}/")
        self.assertEqual(Subscription.objects.get().expires_at, exp)

    def test_expired_subscription_falls_back_to_free(self):
        Subscription.objects.create(user=self.doc, plan="business", cycle="monthly",
                                    started_at=timezone.now() - timedelta(days=40),
                                    expires_at=timezone.now() - timedelta(days=10))
        self.assertEqual(get_plan(self.doc).key, "free")

    def test_renewal_stacks_time(self):
        Subscription.objects.create(user=self.doc, plan="pro", cycle="monthly",
                                    started_at=timezone.now(), expires_at=timezone.now() + timedelta(days=10))
        self.client.post("/doctor/plans/checkout/", {"plan": "pro", "cycle": "yearly"})
        pay = Payment.objects.get()
        self.client.post(f"/doctor/plans/demo-pay/{pay.pk}/")
        days = (Subscription.objects.get().expires_at - timezone.now()).days
        self.assertIn(days, (374, 375))                              # 10 left + 365

    def test_lookup_limit_and_refresh_not_counted(self):
        for i in range(10):
            AccessLog.objects.create(patient_phone=f"98000000{i:02d}", doctor=self.doc, doctor_name="Dr A")
        r = self.client.get("/doctor/patients/", {"phone": "9111111111"})
        self.assertContains(r, "look-up limit reached")
        AccessLog.objects.all().delete()
        for i in range(9):
            AccessLog.objects.create(patient_phone=f"98000000{i:02d}", doctor=self.doc, doctor_name="Dr A")
        self.client.get("/doctor/patients/", {"phone": "9111111111"})   # 10th - allowed
        self.client.get("/doctor/patients/", {"phone": "9111111111"})   # refresh - still allowed, not counted
        self.assertEqual(AccessLog.objects.count(), 10)

    def test_unverified_cannot_subscribe_and_patient_cannot_see_billing(self):
        self.doc.is_verified = False; self.doc.save()
        self.client.post("/doctor/plans/checkout/", {"plan": "pro", "cycle": "monthly"})
        self.assertEqual(Payment.objects.count(), 0)
        User.objects.create_user("9876543210", "pass12345X", first_name="P")
        self.client.post("/logout/")
        self.client.post("/patient/login/", {"phone": "9876543210", "password": "pass12345X"})
        self.assertEqual(self.client.get("/doctor/plans/").status_code, 302)

    def test_other_doctor_cannot_open_my_invoice(self):
        self.client.post("/doctor/plans/checkout/", {"plan": "business", "cycle": "monthly"})
        pay = Payment.objects.get()
        self.client.post(f"/doctor/plans/demo-pay/{pay.pk}/")
        User.objects.create_user("9000000002", "pass12345X", role="doctor", first_name="Dr B", is_verified=True)
        self.client.post("/logout/")
        self.client.post("/doctor/login/", {"phone": "9000000002", "password": "pass12345X"})
        self.assertEqual(self.client.get(f"/doctor/invoice/{pay.pk}/").status_code, 404)

    @override_settings(PAYMENTS_DEMO_MODE=False, RAZORPAY_KEY_ID="rzp_test_x", RAZORPAY_KEY_SECRET="secret123")
    def test_razorpay_signature_flow(self):
        with mock.patch.object(razorpay, "create_order", return_value={"id": "order_ABC123"}):
            r = self.client.post("/doctor/plans/checkout/", {"plan": "pro", "cycle": "monthly"})
        self.assertContains(r, "order_ABC123"); self.assertContains(r, "rzp_test_x")
        # forged signature is rejected
        bad = self.client.post("/doctor/plans/verify/", {"razorpay_order_id": "order_ABC123",
                               "razorpay_payment_id": "pay_1", "razorpay_signature": "nope"})
        self.assertEqual(get_plan(self.doc).key, "free")
        Payment.objects.update(status="created")
        good_sig = hmac.new(b"secret123", b"order_ABC123|pay_1", hashlib.sha256).hexdigest()
        self.client.post("/doctor/plans/verify/", {"razorpay_order_id": "order_ABC123",
                         "razorpay_payment_id": "pay_1", "razorpay_signature": good_sig})
        self.assertEqual(get_plan(self.doc).key, "pro")

    @override_settings(PAYMENTS_DEMO_MODE=False)
    def test_demo_pay_disabled_in_production(self):
        self.client.post("/doctor/plans/checkout/", {"plan": "pro", "cycle": "monthly"})
        self.assertEqual(Payment.objects.count(), 0)                 # not configured -> no order at all


    def test_file_picker_multiple_only_on_paid_plans(self):
        self.assertNotIn(" multiple", self.client.get("/doctor/upload/").content.decode().split('name="files"')[1].split(">")[0])
        Subscription.objects.create(user=self.doc, plan="pro", cycle="monthly",
                                    started_at=timezone.now(), expires_at=timezone.now() + timedelta(days=5))
        self.assertIn("multiple", self.client.get("/doctor/upload/").content.decode().split('name="files"')[1].split(">")[0])
