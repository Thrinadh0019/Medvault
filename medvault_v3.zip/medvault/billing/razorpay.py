"""Tiny Razorpay client (Orders API + signature check) using only the standard library."""
import base64
import hashlib
import hmac
import json
import urllib.error
import urllib.request

from django.conf import settings


class PaymentError(Exception):
    pass


def configured():
    return bool(settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_SECRET)


def create_order(amount_paise, receipt, notes=None):
    body = json.dumps({"amount": amount_paise, "currency": "INR", "receipt": receipt[:40], "notes": notes or {}}).encode()
    token = base64.b64encode(f"{settings.RAZORPAY_KEY_ID}:{settings.RAZORPAY_KEY_SECRET}".encode()).decode()
    req = urllib.request.Request(
        "https://api.razorpay.com/v1/orders", data=body, method="POST",
        headers={"Content-Type": "application/json", "Authorization": f"Basic {token}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        raise PaymentError("Could not reach the payment gateway. Please try again.") from exc


def verify_signature(order_id, payment_id, signature):
    expected = hmac.new(
        settings.RAZORPAY_KEY_SECRET.encode(), f"{order_id}|{payment_id}".encode(), hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature or "")
