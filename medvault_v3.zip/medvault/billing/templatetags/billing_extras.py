from django import template

register = template.Library()


def _indian(n):
    s = str(int(n))
    if len(s) <= 3:
        return s
    head, tail, parts = s[:-3], s[-3:], []
    while len(head) > 2:
        parts.insert(0, head[-2:])
        head = head[:-2]
    if head:
        parts.insert(0, head)
    return ",".join(parts + [tail])


@register.filter
def rupees(paise):
    """49900 -> ₹499 ; 58882 -> ₹588.82 (Indian digit grouping)."""
    r, p = divmod(int(paise or 0), 100)
    return f"₹{_indian(r)}" + (f".{p:02d}" if p else "")


@register.filter
def rupees2(paise):
    r, p = divmod(int(paise or 0), 100)
    return f"₹{_indian(r)}.{p:02d}"
