from django.conf import settings
from django.db import models


class Subscription(models.Model):
    """One row per doctor/lab. No row (or an expired one) means the free plan."""
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="subscription")
    plan = models.CharField(max_length=20, default="free")
    cycle = models.CharField(max_length=10, default="monthly")
    started_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.user} - {self.plan} until {self.expires_at}"


class Payment(models.Model):
    CREATED, PAID, FAILED = "created", "paid", "failed"
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="payments")
    plan = models.CharField(max_length=20)
    cycle = models.CharField(max_length=10)
    base_amount = models.PositiveIntegerField(help_text="paise, excluding GST")
    gst_amount = models.PositiveIntegerField(help_text="paise")
    total_amount = models.PositiveIntegerField(help_text="paise, what the customer pays")
    currency = models.CharField(max_length=3, default="INR")
    razorpay_order_id = models.CharField(max_length=60, unique=True)
    razorpay_payment_id = models.CharField(max_length=60, blank=True)
    status = models.CharField(max_length=10, default=CREATED)
    invoice_no = models.CharField(max_length=30, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    @property
    def is_demo(self):
        return self.razorpay_order_id.startswith("demo_")

    def __str__(self):
        return f"{self.invoice_no or self.razorpay_order_id} ({self.status})"
