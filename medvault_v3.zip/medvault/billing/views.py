import uuid

from django.conf import settings
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from accounts.decorators import doctor_required

from . import razorpay
from .models import Payment
from .plans import PLAN_LIST, PLANS, gst_for
from .services import activate, get_plan, get_subscription, usage


def _payment_or_404(user, **filters):
    try:
        return get_object_or_404(Payment, user=user, **filters)
    except (ValidationError, ValueError):
        raise Http404()


@doctor_required
def plans(request):
    user = request.user
    plan = get_plan(user)
    sub = get_subscription(user)
    return render(request, "billing/plans.html", {
        "plans": PLAN_LIST,
        "current": plan,
        "expires_at": sub.expires_at if sub and not plan.is_free else None,
        "usage": usage(user, plan),
        "payments": list(Payment.objects.filter(user=user, status=Payment.PAID)[:20]),
        "can_pay": razorpay.configured() or settings.PAYMENTS_DEMO_MODE,
        "gst_percent": settings.GST_PERCENT,
    })


@doctor_required
@require_POST
def checkout(request):
    user = request.user
    plan = PLANS.get(request.POST.get("plan", ""))
    cycle = request.POST.get("cycle", "monthly")
    if plan is None or plan.is_free or cycle not in ("monthly", "yearly"):
        messages.error(request, "Please choose a paid plan.")
        return redirect("plans")
    if not user.is_verified:
        messages.error(request, "Your account must be verified by an administrator before you can subscribe.")
        return redirect("plans")
    if not (razorpay.configured() or settings.PAYMENTS_DEMO_MODE):
        messages.error(request, "Online payments are not set up yet. Please contact support.")
        return redirect("plans")

    base = plan.price(cycle)
    gst = gst_for(base)
    total = base + gst
    if razorpay.configured():
        try:
            order = razorpay.create_order(total, f"mv_{uuid.uuid4().hex[:12]}", {"user": user.phone, "plan": plan.key, "cycle": cycle})
        except razorpay.PaymentError as exc:
            messages.error(request, str(exc))
            return redirect("plans")
        order_id = order["id"]
    else:
        order_id = f"demo_{uuid.uuid4().hex[:16]}"

    payment = Payment.objects.create(
        user=user, plan=plan.key, cycle=cycle, base_amount=base, gst_amount=gst,
        total_amount=total, razorpay_order_id=order_id,
    )
    return render(request, "billing/checkout.html", {
        "payment": payment, "plan": plan, "gst_percent": settings.GST_PERCENT,
        "razorpay_key": settings.RAZORPAY_KEY_ID, "use_razorpay": razorpay.configured(),
    })


@doctor_required
@require_POST
def verify(request):
    """Razorpay Checkout posts here after a successful payment."""
    order_id = request.POST.get("razorpay_order_id", "")
    payment_id = request.POST.get("razorpay_payment_id", "")
    signature = request.POST.get("razorpay_signature", "")
    payment = _payment_or_404(request.user, razorpay_order_id=order_id)
    if payment.is_demo or not razorpay.verify_signature(order_id, payment_id, signature):
        payment.status = Payment.FAILED if payment.status != Payment.PAID else payment.status
        payment.save()
        messages.error(request, "We couldn't verify that payment. If money was deducted, it will be refunded automatically.")
        return redirect("plans")
    payment.razorpay_payment_id = payment_id
    activate(payment)
    messages.success(request, f"Payment received. You are now on the {PLANS[payment.plan].name} plan.")
    return redirect("plans")


@doctor_required
@require_POST
def demo_pay(request, pk):
    """Test-mode only: pretend the payment succeeded so you can try the full flow."""
    if not settings.PAYMENTS_DEMO_MODE:
        raise Http404()
    payment = _payment_or_404(request.user, pk=pk)
    if not payment.is_demo:
        raise Http404()
    payment.razorpay_payment_id = f"demo_pay_{uuid.uuid4().hex[:10]}"
    activate(payment)
    messages.success(request, f"Test payment recorded. You are now on the {PLANS[payment.plan].name} plan.")
    return redirect("plans")


@doctor_required
def invoice(request, pk):
    payment = _payment_or_404(request.user, pk=pk, status=Payment.PAID)
    return render(request, "billing/invoice.html", {
        "p": payment, "plan": PLANS[payment.plan], "gst_percent": settings.GST_PERCENT,
        "seller": {"name": settings.BUSINESS_NAME, "gstin": settings.BUSINESS_GSTIN, "address": settings.BUSINESS_ADDRESS},
    })
