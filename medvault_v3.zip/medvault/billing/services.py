import uuid
from datetime import timedelta

from django.utils import timezone

from reports.models import AccessLog, Report

from .models import Payment, Subscription
from .plans import FREE, PERIOD_DAYS, PLANS


def month_start():
    return timezone.localtime().replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def get_subscription(user):
    return Subscription.objects.filter(user=user).first()


def get_plan(user):
    sub = get_subscription(user)
    if sub and sub.plan in PLANS and sub.expires_at and sub.expires_at > timezone.now():
        return PLANS[sub.plan]
    return FREE


def uploads_used(user):
    return Report.objects.filter(uploaded_by=user, uploaded_at__gte=month_start()).count()


def lookups_used(user):
    return AccessLog.objects.filter(doctor=user, viewed_at__gte=month_start()).count()


def _pct(used, limit):
    return 0 if not limit else min(100, round(used * 100 / limit))


def usage(user, plan=None):
    plan = plan or get_plan(user)
    up, lk = uploads_used(user), lookups_used(user)
    return {
        "plan": plan,
        "uploads_used": up, "uploads_limit": plan.uploads, "uploads_pct": _pct(up, plan.uploads),
        "lookups_used": lk, "lookups_limit": plan.lookups, "lookups_pct": _pct(lk, plan.lookups),
    }


def activate(payment):
    """Mark a payment as paid and (extend the) subscription. Safe to call twice."""
    if payment.status == Payment.PAID:
        return
    now = timezone.now()
    payment.status = Payment.PAID
    payment.paid_at = now
    payment.invoice_no = f"MV-{timezone.localtime(now):%Y%m%d}-{uuid.uuid4().hex[:6].upper()}"
    payment.save()

    sub = get_subscription(payment.user) or Subscription(user=payment.user)
    start = now
    if sub.plan == payment.plan and sub.expires_at and sub.expires_at > now:
        start = sub.expires_at                      # renewing the same plan: stack on top
    sub.plan, sub.cycle = payment.plan, payment.cycle
    sub.started_at = now
    sub.expires_at = start + timedelta(days=PERIOD_DAYS[payment.cycle])
    sub.save()
