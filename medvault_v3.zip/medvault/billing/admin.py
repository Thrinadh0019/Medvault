from django.contrib import admin

from .models import Payment, Subscription


@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    """Admins can also grant / extend plans by hand (e.g. free trials, partner labs)."""
    list_display = ("user", "plan", "cycle", "started_at", "expires_at")
    list_filter = ("plan",)
    raw_id_fields = ("user",)


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("invoice_no", "user", "plan", "cycle", "total_amount", "status", "created_at")
    list_filter = ("status", "plan")
    search_fields = ("invoice_no", "razorpay_order_id", "razorpay_payment_id")
    raw_id_fields = ("user",)
