"""Subscription plans for doctors and labs. Prices are in PAISE (1 rupee = 100 paise),
excluding GST. Edit this file to change prices or limits."""
from dataclasses import dataclass

from django.conf import settings


@dataclass(frozen=True)
class Plan:
    key: str
    name: str
    tagline: str
    monthly: int             # paise / month
    yearly: int              # paise / year (10 x monthly = 2 months free)
    uploads: int | None      # report uploads per calendar month (None = unlimited)
    lookups: int | None      # patient look-ups per calendar month (None = unlimited)
    max_files: int           # files allowed in a single upload
    badge: str               # shown to patients next to the uploader's name
    features: tuple
    popular: bool = False

    @property
    def is_free(self):
        return self.monthly == 0

    def price(self, cycle):
        return self.yearly if cycle == "yearly" else self.monthly


FREE = Plan(
    key="free", name="Starter", tagline="Try it with your first patients",
    monthly=0, yearly=0, uploads=20, lookups=10, max_files=1, badge="",
    features=("20 report uploads / month", "10 patient look-ups / month", "One file per upload", "Verified doctor / lab access"),
)
PRO = Plan(
    key="pro", name="Pro", tagline="For busy clinics and small labs",
    monthly=49900, yearly=499000, uploads=300, lookups=None, max_files=5, badge="Pro", popular=True,
    features=("300 report uploads / month", "Unlimited patient look-ups", "Upload up to 5 files at once", "“Pro” badge on your reports"),
)
BUSINESS = Plan(
    key="business", name="Business", tagline="For diagnostic centres and hospitals",
    monthly=149900, yearly=1499000, uploads=None, lookups=None, max_files=20, badge="Business",
    features=("Unlimited report uploads", "Unlimited patient look-ups", "Bulk upload: 20 files at once", "“Business” badge on your reports"),
)

PLAN_LIST = [FREE, PRO, BUSINESS]
PLANS = {p.key: p for p in PLAN_LIST}
PERIOD_DAYS = {"monthly": 30, "yearly": 365}


def gst_for(base_paise):
    return round(base_paise * settings.GST_PERCENT / 100)
