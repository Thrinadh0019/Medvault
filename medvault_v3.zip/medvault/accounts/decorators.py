from functools import wraps

from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect


def role_required(role, login_url_name):
    def decorator(view):
        @wraps(view)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect(login_url_name)
            if request.user.role != role:
                return redirect("home")
            return view(request, *args, **kwargs)
        return wrapper
    return decorator


patient_required = role_required("patient", "patient_login")
doctor_required = role_required("doctor", "doctor_login")
