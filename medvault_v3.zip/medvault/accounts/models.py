from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.db import models
from django.utils import timezone

from .utils import normalize_phone


class UserManager(BaseUserManager):
    use_in_migrations = True

    def _create(self, phone, password, **extra):
        phone = normalize_phone(phone)
        if len(phone) != 10:
            raise ValueError("A valid 10-digit phone number is required.")
        user = self.model(phone=phone, **extra)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, phone, password=None, **extra):
        extra.setdefault("role", User.PATIENT)
        return self._create(phone, password, **extra)

    def create_superuser(self, phone, password=None, **extra):
        extra.update(is_staff=True, is_superuser=True, role=User.ADMIN, is_verified=True)
        return self._create(phone, password, **extra)


class User(AbstractBaseUser):
    """Custom user. Deliberately does NOT use PermissionsMixin (its groups /
    permissions are many-to-many joins, which MongoDB doesn't do). Access is
    controlled by `role`, and admins by `is_superuser`."""

    PATIENT = "patient"
    DOCTOR = "doctor"
    ADMIN = "admin"
    ROLE_CHOICES = [(PATIENT, "Patient"), (DOCTOR, "Doctor / Lab"), (ADMIN, "Admin")]

    phone = models.CharField(max_length=10, unique=True)
    first_name = models.CharField("Full name", max_length=150, blank=True)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default=PATIENT)
    # Doctors/labs must be verified before they can upload reports.
    is_verified = models.BooleanField(default=False)
    registration_number = models.CharField(
        "Medical council / lab licence number", max_length=50, blank=True
    )
    organization = models.CharField("Clinic / lab name", max_length=120, blank=True)
    # Patients can switch off doctor look-ups of their reports.
    allow_doctor_lookup = models.BooleanField("Allow verified doctors to look up my reports", default=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    USERNAME_FIELD = "phone"
    REQUIRED_FIELDS = []
    objects = UserManager()

    # Django admin permission hooks: superusers can do everything.
    def has_perm(self, perm, obj=None):
        return self.is_active and self.is_superuser

    def has_module_perms(self, app_label):
        return self.is_active and self.is_superuser

    @property
    def initial(self):
        return (self.first_name or "?")[:1].upper()

    @property
    def display_name(self):
        return self.first_name or self.phone

    def __str__(self):
        return f"{self.display_name} ({self.phone})"
