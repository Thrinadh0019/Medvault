from django.contrib import messages
from django.contrib.auth import login, logout
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from billing.plans import PLAN_LIST

from .forms import DoctorLoginForm, DoctorRegisterForm, PatientLoginForm, PatientRegisterForm


def home(request):
    if request.user.is_authenticated:
        if request.user.role == "patient":
            return redirect("patient_dashboard")
        if request.user.role == "doctor":
            return redirect("doctor_lookup")
    return render(request, "home.html", {"plans": PLAN_LIST})


def _login(request, form_class, template, next_url):
    form = form_class(request, request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.user)
        return redirect(next_url)
    return render(request, template, {"form": form})


def patient_login(request):
    return _login(request, PatientLoginForm, "accounts/patient_login.html", "patient_dashboard")


def doctor_login(request):
    return _login(request, DoctorLoginForm, "accounts/doctor_login.html", "doctor_lookup")


def _register(request, form_class, template, next_url):
    form = form_class(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        if user.role == "doctor" and not user.is_verified:
            messages.info(request, "Account created. You can upload reports once an admin verifies you.")
        return redirect(next_url)
    return render(request, template, {"form": form})


def patient_register(request):
    return _register(request, PatientRegisterForm, "accounts/patient_register.html", "patient_dashboard")


def doctor_register(request):
    return _register(request, DoctorRegisterForm, "accounts/doctor_register.html", "doctor_lookup")


@require_POST
def logout_view(request):
    logout(request)
    return redirect("home")
