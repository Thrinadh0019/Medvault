from django import forms
from django.contrib import admin

from .models import User


class UserAdminForm(forms.ModelForm):
    new_password = forms.CharField(
        required=False, widget=forms.PasswordInput,
        help_text="Fill in only to set or change the password.",
    )

    class Meta:
        model = User
        fields = ["phone", "first_name", "role", "is_verified", "registration_number",
                  "organization", "is_active", "is_staff", "is_superuser"]

    def save(self, commit=True):
        user = super().save(commit=False)
        if self.cleaned_data.get("new_password"):
            user.set_password(self.cleaned_data["new_password"])
        elif not user.password:
            user.set_unusable_password()
        if commit:
            user.save()
        return user


@admin.register(User)
class CustomUserAdmin(admin.ModelAdmin):
    form = UserAdminForm
    ordering = ("phone",)
    list_display = ("phone", "first_name", "role", "is_verified", "organization")
    list_filter = ("role", "is_verified")
    search_fields = ("phone", "first_name", "organization")
    actions = ["verify_selected"]

    def get_fields(self, request, obj=None):
        return list(UserAdminForm.Meta.fields) + ["new_password"]

    @admin.action(description="Verify selected doctors/labs")
    def verify_selected(self, request, queryset):
        for user in queryset:   # per-object save (no multi-document update needed)
            user.is_verified = True
            user.save(update_fields=["is_verified"])
