import re


def normalize_phone(value: str) -> str:
    """Keep digits only and use the last 10 (strips +91, spaces, dashes).
    Change this function if you need international numbers."""
    digits = re.sub(r"\D", "", value or "")
    return digits[-10:]
