from django import forms
from django.conf import settings
from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password

from .models import User
from .utils import normalize_phone


PLACEHOLDERS = {
    "phone": "98765 43210",
    "first_name": "Full name",
    "organization": "e.g. City Diagnostics",
    "registration_number": "Licence / registration number",
}


class StyledMixin:
    """Adds placeholders and the data attributes the front-end script uses."""

    def _style_fields(self):
        for name, field in self.fields.items():
            attrs = field.widget.attrs
            if name in PLACEHOLDERS:
                attrs["placeholder"] = PLACEHOLDERS[name]
            if name == "phone":
                attrs.update({"inputmode": "numeric", "autocomplete": "tel-national", "data-phone": ""})
            if isinstance(field.widget, forms.PasswordInput):
                attrs["autocomplete"] = "current-password" if name == "password" else "new-password"


class LoginForm(StyledMixin, forms.Form):
    role = None  # set by subclasses
    phone = forms.CharField(label="Phone number", max_length=20, widget=forms.TextInput(attrs={"placeholder": "98765 43210", "inputmode": "tel", "autocomplete": "tel"}))
    password = forms.CharField(widget=forms.PasswordInput)

    def __init__(self, request=None, *args, **kwargs):
        self.request = request
        self.user = None
        super().__init__(*args, **kwargs)
        self._style_fields()

    def clean(self):
        data = super().clean()
        phone, password = data.get("phone"), data.get("password")
        if phone and password:
            user = authenticate(self.request, username=normalize_phone(phone), password=password)
            if user is None or user.role != self.role:
                raise forms.ValidationError("Phone number or password is incorrect.")
            self.user = user
        return data


class PatientLoginForm(LoginForm):
    role = User.PATIENT


class DoctorLoginForm(LoginForm):
    role = User.DOCTOR


class BaseRegisterForm(StyledMixin, forms.ModelForm):
    role = None
    password1 = forms.CharField(label="Password", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Confirm password", widget=forms.PasswordInput)
    phone = forms.CharField(label="Phone number", max_length=20, widget=forms.TextInput(attrs={"placeholder": "98765 43210", "inputmode": "tel", "autocomplete": "tel"}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style_fields()

    def clean_phone(self):
        phone = normalize_phone(self.cleaned_data["phone"])
        if len(phone) != 10:
            raise forms.ValidationError("Enter a valid 10-digit phone number.")
        if User.objects.filter(phone=phone).exists():
            raise forms.ValidationError("This phone number is already registered.")
        return phone

    def clean(self):
        data = super().clean()
        if data.get("password1") and data.get("password1") != data.get("password2"):
            self.add_error("password2", "Passwords do not match.")
        if data.get("password1"):
            validate_password(data["password1"])
        return data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = self.role
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user


class PatientRegisterForm(BaseRegisterForm):
    role = User.PATIENT
    first_name = forms.CharField(label="Full name", max_length=150)

    class Meta:
        model = User
        fields = ["first_name", "phone"]


class DoctorRegisterForm(BaseRegisterForm):
    role = User.DOCTOR
    first_name = forms.CharField(label="Full name", max_length=150)

    class Meta:
        model = User
        fields = ["first_name", "phone", "organization", "registration_number"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["organization"].required = True
        self.fields["registration_number"].required = True

    def save(self, commit=True):
        user = super().save(commit=False)
        user.is_verified = settings.DOCTOR_AUTO_APPROVE
        if commit:
            user.save()
        return user
