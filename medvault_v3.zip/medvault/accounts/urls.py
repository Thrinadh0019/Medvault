from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("patient/login/", views.patient_login, name="patient_login"),
    path("patient/register/", views.patient_register, name="patient_register"),
    path("doctor/login/", views.doctor_login, name="doctor_login"),
    path("doctor/register/", views.doctor_register, name="doctor_register"),
    path("logout/", views.logout_view, name="logout"),
]
