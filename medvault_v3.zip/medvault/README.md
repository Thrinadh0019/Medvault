# MedVault – medical reports by phone number (Django + MongoDB)

Doctors/labs upload a report against a patient's phone number. The patient logs in
with that phone number and sees the file name with its upload date and time.

## 1. Get a MongoDB
Pick one:
- **Local:** install MongoDB Community Server and start it (default `mongodb://localhost:27017`).
- **Cloud (free):** create a free cluster on MongoDB Atlas, add your IP to the access list,
  and copy the connection string (`mongodb+srv://user:password@cluster.mongodb.net/`).

## 2. Run it
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Only needed if NOT using local MongoDB on the default port:
export MONGODB_URI="mongodb+srv://user:password@cluster.mongodb.net/"   # Windows: set MONGODB_URI=...
export MONGODB_NAME="medvault"

python manage.py migrate
python manage.py createsuperuser                      # phone number + password (for /admin/)
python manage.py runserver
```
Open http://127.0.0.1:8000/

| Who | Register | Log in |
|---|---|---|
| Patient | /patient/register/ | /patient/login/ |
| Doctor / Lab | /doctor/register/ | /doctor/login/ |
| Admin | – | /admin/ (use phone number as username) |

## Features
- **Patients:** dashboard with all reports grouped by month (file name + upload date/time), filter box,
  stats, a log of every doctor who looked up their records, and a switch to turn doctor look-ups off.
- **Doctors / labs:** **Find patient** – enter a mobile number to see *all* reports for that patient
  (from every doctor and lab); **Upload report** – drag & drop PDF/JPG/PNG against a mobile number.
- Every doctor look-up is recorded (`AccessLog`) and shown to the patient. Only *verified* doctors can look up.

## Try it
1. Register a doctor, then upload a PDF for phone `9876543210`.
2. Register a patient with `9876543210` and log in – the report is there with its timestamp.
3. Log in as the doctor → **Find patient** → type `9876543210` to see all reports for that patient.
   (Order doesn't matter: reports uploaded before the patient signs up still appear.)

## What's stored where
- **MongoDB:** users, report records (phone, file path, original name, uploader, timestamp), sessions.
- **`private_media/` folder:** the actual uploaded files (not public; served only by a permission-checked view).
  For production, use private cloud storage (S3, GCS, Azure Blob) instead of local disk.

## MongoDB-specific notes
- Uses the official `django-mongodb-backend`. Django's admin/auth/contenttypes use
  `mongo_migrations/` (already generated) so they get ObjectId primary keys.
- MongoDB has no joins, so the custom `User` model has no groups/permissions
  (access is by `role`; admins use `is_superuser`), and each report stores a copy of the
  uploader's name/clinic.
- Multi-document transactions need a replica set (Atlas always has one). The app doesn't rely on them.
- If you change a model, run: `python manage.py makemigrations accounts reports`


## Nearby labs & hospitals (Google)
Patients get a **Nearby labs** page: *Use my location* or type an area, switch between Labs / Hospitals, see
distance, rating, open-now, phone and one-tap Google Maps directions, plus a map.

1. In [Google Cloud Console](https://console.cloud.google.com/) create a project and **enable billing** (Google gives a monthly free credit).
2. Enable **Places API (New)** and create a **server key**, restricted to *Places API (New)* and your server IP.
   `export GOOGLE_PLACES_API_KEY="..."`   (never sent to the browser)
3. *(Optional, for the map)* Enable **Maps JavaScript API**, create a **browser key** restricted to your website domain
   (HTTP referrers), and create a **Map ID** (Map Management).
   `export GOOGLE_MAPS_BROWSER_KEY="..."` and `export GOOGLE_MAP_ID="..."`
4. **Set a budget alert** in Google Cloud so usage can never surprise you.

Without keys the page still works in a basic mode: it opens Google Maps itself with a search near the patient.
Cost tip: `PLACES_INCLUDE_DETAILS=0` removes rating / hours / phone from the request (cheaper SKU).
Patient location is used for the single request and is never stored. Google's terms restrict caching place data, so results are not cached.

## Subscription plans for doctors & labs
Defined in `billing/plans.py` (edit prices and limits there). Prices exclude GST (default 18%, `GST_PERCENT`).

| | Starter (free) | Pro | Business |
|---|---|---|---|
| Price | Free | Rs 499/mo or Rs 4,990/yr | Rs 1,499/mo or Rs 14,990/yr |
| Report uploads | 20 / month | 300 / month | Unlimited |
| Patient look-ups | 10 / month | Unlimited | Unlimited |
| Files per upload | 1 | 5 | 20 |
| Badge on reports | none | Pro | Business |

- Limits reset on the 1st of each month (IST). Refreshing a patient search within 10 minutes isn't counted again.
- Plans are **prepaid** for 30 / 365 days (no auto-renew). Renewing the same plan stacks time; an expired plan falls back to Starter.
- Doctors see usage meters, an upgrade page, billing history and printable invoices (**Plan & billing** in the menu).
- Admins can grant or extend any plan manually in `/admin/` -> Subscriptions (free trials, partner labs).

**Payments with Razorpay**
1. Create an account at razorpay.com and copy the **Test Mode** keys: `export RAZORPAY_KEY_ID=rzp_test_...` and `export RAZORPAY_KEY_SECRET=...`
2. Test with Razorpay's test UPI/cards, then switch to Live keys after KYC.
3. Without keys, **demo mode** (only while `DJANGO_DEBUG=1`) lets you click "Simulate payment" to try the whole flow. It is disabled in production.
4. Fill `BUSINESS_NAME`, `BUSINESS_GSTIN`, `BUSINESS_ADDRESS` so invoices carry your real details.

Payment security: the server creates the order and amount, and activates a plan only after verifying Razorpay's signature (HMAC-SHA256). Card data never touches your server.

## Environment variables
`MONGODB_URI`, `MONGODB_NAME`, `DJANGO_SECRET_KEY`, `DJANGO_DEBUG`, `DJANGO_ALLOWED_HOSTS`, `DOCTOR_AUTO_APPROVE`,
`GOOGLE_PLACES_API_KEY`, `GOOGLE_MAPS_BROWSER_KEY`, `GOOGLE_MAP_ID`, `NEARBY_RADIUS_M`, `PLACES_REGION`, `PLACES_INCLUDE_DETAILS`,
`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `PAYMENTS_DEMO_MODE`, `GST_PERCENT`, `BUSINESS_NAME`, `BUSINESS_GSTIN`, `BUSINESS_ADDRESS`

## Before taking real payments
- Invoice numbers are unique but not a gap-free series. Indian GST rules need a consecutive series, so have your accountant confirm the format.
- Add a Razorpay **webhook** (`payment.captured`) as a backup for users who close the tab right after paying.
- Add Terms of Service, Privacy Policy and Refund Policy pages (Razorpay requires them for live mode).

## Before going live
- Set env vars: `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=0`, `DJANGO_ALLOWED_HOSTS=yourdomain.com`
- Set `DOCTOR_AUTO_APPROVE=0` and verify doctors in /admin/ (tick **is_verified**).
- Add OTP verification of patient phone numbers (SMS provider) so nobody can register
  someone else's number and read their reports. This is the most important addition.
- Serve over HTTPS and use authenticated MongoDB (Atlas does this by default).
- Medical data is covered by privacy laws (e.g. India's DPDP Act) – get legal advice first.
