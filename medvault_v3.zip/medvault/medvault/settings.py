import os
from pathlib import Path

import django_mongodb_backend

BASE_DIR = Path(__file__).resolve().parent.parent

# --- Security: override these with environment variables in production ---
SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-only-change-me-before-deploying")
DEBUG = os.environ.get("DJANGO_DEBUG", "1") == "1"
ALLOWED_HOSTS = os.environ.get("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",")

# In development, doctors/labs can upload right after registering.
# In production set DOCTOR_AUTO_APPROVE=0 and approve doctors in /admin/ (is_verified).
DOCTOR_AUTO_APPROVE = os.environ.get("DOCTOR_AUTO_APPROVE", "1") == "1"

INSTALLED_APPS = [
    "medvault.apps.MongoAdminConfig",
    "medvault.apps.MongoAuthConfig",
    "medvault.apps.MongoContentTypesConfig",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "accounts",
    "reports",
    "billing",
    "nearby",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "medvault.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "billing.context.plan_context",
            ],
        },
    },
]

WSGI_APPLICATION = "medvault.wsgi.application"

# --- MongoDB ---
# Local:  mongodb://localhost:27017
# Atlas:  mongodb+srv://<user>:<password>@<cluster>.mongodb.net/
MONGODB_URI = os.environ.get("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_NAME = os.environ.get("MONGODB_NAME", "medvault")
DATABASES = {
    "default": django_mongodb_backend.parse_uri(MONGODB_URI, db_name=MONGODB_NAME),
}

# Migrations for Django's built-in apps must be generated for MongoDB
# (already included in the mongo_migrations/ folder).
MIGRATION_MODULES = {
    "admin": "mongo_migrations.admin",
    "auth": "mongo_migrations.auth",
    "contenttypes": "mongo_migrations.contenttypes",
}

AUTH_USER_MODEL = "accounts.User"
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", "OPTIONS": {"min_length": 8}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"

# Reports are PRIVATE: stored outside any public URL and only served
# through the permission-checked `download_report` view.
MEDIA_ROOT = BASE_DIR / "private_media"
MAX_REPORT_SIZE_MB = 10
ALLOWED_REPORT_EXTENSIONS = [".pdf", ".jpg", ".jpeg", ".png"]
DATA_UPLOAD_MAX_MEMORY_SIZE = 12 * 1024 * 1024

LOGIN_URL = "home"
DEFAULT_AUTO_FIELD = "django_mongodb_backend.fields.ObjectIdAutoField"

if not DEBUG:
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_SSL_REDIRECT = True
    SECURE_HSTS_SECONDS = 31536000


# ======================= Payments (Razorpay) =======================
# Create keys at https://dashboard.razorpay.com (use Test Mode first).
RAZORPAY_KEY_ID = os.environ.get("RAZORPAY_KEY_ID", "")
RAZORPAY_KEY_SECRET = os.environ.get("RAZORPAY_KEY_SECRET", "")
# Demo mode lets you test the whole subscription flow WITHOUT real payments.
# It is ON by default only while DEBUG=1 and no Razorpay keys are set.
_demo = os.environ.get("PAYMENTS_DEMO_MODE")
PAYMENTS_DEMO_MODE = (_demo == "1") if _demo is not None else (DEBUG and not (RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET))
GST_PERCENT = int(os.environ.get("GST_PERCENT", "18"))
# Shown on invoices - fill in your real business details.
BUSINESS_NAME = os.environ.get("BUSINESS_NAME", "MedVault (your company name)")
BUSINESS_GSTIN = os.environ.get("BUSINESS_GSTIN", "")
BUSINESS_ADDRESS = os.environ.get("BUSINESS_ADDRESS", "Your registered address, City, State, PIN")

# ===================== Google Maps / Places =====================
# GOOGLE_PLACES_API_KEY : SERVER key (enable "Places API (New)"; restrict by server IP). Never sent to browsers.
# GOOGLE_MAPS_BROWSER_KEY: BROWSER key (enable "Maps JavaScript API"; restrict by HTTP referrer). Optional: without it
#                          the list still works, only the map is hidden.
GOOGLE_PLACES_API_KEY = os.environ.get("GOOGLE_PLACES_API_KEY", "")
GOOGLE_MAPS_BROWSER_KEY = os.environ.get("GOOGLE_MAPS_BROWSER_KEY", "")
GOOGLE_MAP_ID = os.environ.get("GOOGLE_MAP_ID", "DEMO_MAP_ID")  # create your own Map ID in Google Cloud for production
NEARBY_RADIUS_M = int(os.environ.get("NEARBY_RADIUS_M", "5000"))
PLACES_REGION = os.environ.get("PLACES_REGION", "IN")
# Rating / opening hours / phone cost more per request. Set to 0 for the cheapest field set.
PLACES_INCLUDE_DETAILS = os.environ.get("PLACES_INCLUDE_DETAILS", "1") == "1"
