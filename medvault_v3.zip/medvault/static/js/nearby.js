(() => {
  const root = document.querySelector("[data-nearby]");
  if (!root) return;

  const API = root.dataset.api;
  const placesOn = root.dataset.places === "1";
  const mapsKey = root.dataset.mapsKey;
  const mapId = root.dataset.mapId || "DEMO_MAP_ID";
  const listEl = root.querySelector("[data-list]");
  const mapEl = root.querySelector("[data-map]");
  const statusEl = root.querySelector("[data-status]");
  const areaForm = root.querySelector("[data-area-form]");
  const areaInput = areaForm.querySelector("input");
  const locBtn = root.querySelector("[data-locate]");
  const radiusEl = root.querySelector("[data-radius]");
  const tabs = root.querySelectorAll("[data-kind]");

  let kind = "lab", origin = null, area = "";
  let mapsPromise = null, map = null, markers = [], info = null;

  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const safeUrl = (u) => (typeof u === "string" && u.startsWith("https://") ? u : "");
  const kindWord = () => (kind === "lab" ? "diagnostic labs" : "hospitals");
  const setStatus = (msg, isError = false) => {
    statusEl.textContent = msg || "";
    statusEl.classList.toggle("err", !!isError);
  };

  // ---------------------------------------------------------- rendering
  const icon = (id) => `<svg class="ic"><use href="#${id}"/></svg>`;

  function cardHtml(p, i) {
    const dist = p.distance_km != null ? `<span class="pill">${esc(p.distance_km)} km</span>` : "";
    const open = p.open_now === true ? '<span class="pill ok">Open now</span>'
               : p.open_now === false ? '<span class="pill closed">Closed now</span>' : "";
    const rating = p.rating ? `<span class="rating">${icon("i-star")} ${esc(p.rating)} <small>(${esc(p.rating_count || 0)})</small></span>` : "";
    const phone = String(p.phone || "").replace(/[^\d+ ]/g, "");
    const dir = safeUrl(p.directions_url), view = safeUrl(p.maps_url);
    return `<article class="place" data-i="${i}" tabindex="0">
      <span class="place-n">${i + 1}</span>
      <div class="place-body">
        <h3>${esc(p.name)}</h3>
        <p class="place-addr">${esc(p.address)}</p>
        <div class="place-meta">${rating}${open}${dist}${p.type ? `<span class="pill soft">${esc(p.type)}</span>` : ""}</div>
        <div class="place-actions">
          ${dir ? `<a class="btn btn-primary btn-sm" href="${dir}" target="_blank" rel="noopener">${icon("i-arrow")} Directions</a>` : ""}
          ${phone ? `<a class="btn btn-ghost btn-sm" href="tel:${phone.replace(/ /g, "")}">${icon("i-phone")} ${esc(phone)}</a>` : ""}
          ${view ? `<a class="btn btn-ghost btn-sm" href="${view}" target="_blank" rel="noopener">View on Google</a>` : ""}
        </div>
      </div></article>`;
  }

  function showList(results) {
    if (!results.length) {
      listEl.innerHTML = `<div class="empty-state"><h3>Nothing found here</h3>
        <p>Try a bigger radius or a different area.</p></div>`;
      return;
    }
    listEl.innerHTML = results.map(cardHtml).join("");
    listEl.querySelectorAll(".place").forEach((el) => {
      const focus = () => focusPlace(Number(el.dataset.i), results, false);
      el.addEventListener("click", (e) => { if (!e.target.closest("a")) focus(); });
      el.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.target.closest("a")) focus(); });
    });
  }

  function skeleton() {
    listEl.innerHTML = Array.from({ length: 4 }, () => '<div class="place skel"></div>').join("");
  }

  // ---------------------------------------------------------- google map (optional)
  function loadMaps() {
    if (mapsPromise) return mapsPromise;
    mapsPromise = new Promise((resolve, reject) => {
      window.__nbMapsReady = resolve;
      const s = document.createElement("script");
      s.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(mapsKey)}&loading=async&v=weekly&callback=__nbMapsReady`;
      s.async = true;
      s.onerror = reject;
      document.head.appendChild(s);
    });
    return mapsPromise;
  }

  async function drawMap(results) {
    if (!mapsKey || !results.length) { mapEl.hidden = true; return; }
    mapEl.hidden = false;
    try {
      await loadMaps();
      const { Map, InfoWindow } = await google.maps.importLibrary("maps");
      const { AdvancedMarkerElement, PinElement } = await google.maps.importLibrary("marker");
      const { LatLngBounds } = await google.maps.importLibrary("core");
      if (!map) {
        map = new Map(mapEl, { center: { lat: results[0].lat, lng: results[0].lng }, zoom: 13, mapId, clickableIcons: false });
        info = new InfoWindow();
      }
      markers.forEach((m) => (m.map = null));
      markers = [];
      const bounds = new LatLngBounds();
      if (origin) {
        const me = new PinElement({ background: "#2456a6", borderColor: "#ffffff", glyphColor: "#ffffff", glyph: "●" });
        markers.push(new AdvancedMarkerElement({ map, position: origin, content: me.element, title: "You are here" }));
        bounds.extend(origin);
      }
      results.forEach((p, i) => {
        const pin = new PinElement({ background: "#0e5a52", borderColor: "#ffffff", glyphColor: "#ffffff", glyph: String(i + 1) });
        const m = new AdvancedMarkerElement({ map, position: { lat: p.lat, lng: p.lng }, content: pin.element, title: p.name });
        m.addListener("click", () => focusPlace(i, results, true));
        markers.push(m);
        bounds.extend({ lat: p.lat, lng: p.lng });
      });
      map.fitBounds(bounds, 48);
    } catch (e) {
      mapEl.hidden = true;   // list still works without the map
    }
  }

  function focusPlace(i, results, scrollList) {
    const p = results[i];
    listEl.querySelectorAll(".place").forEach((el) => el.classList.toggle("active", Number(el.dataset.i) === i));
    if (scrollList) listEl.querySelector(`.place[data-i="${i}"]`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    if (map && info) {
      map.panTo({ lat: p.lat, lng: p.lng });
      const box = document.createElement("div");
      box.style.cssText = "font:600 14px system-ui;color:#13211f;max-width:220px";
      box.textContent = p.name;
      info.setContent(box);
      const marker = markers[(origin ? 1 : 0) + i];
      if (marker) info.open({ map, anchor: marker });
    }
  }

  // ---------------------------------------------------------- search
  async function run() {
    if (!origin && !area) return;

    if (!placesOn) {   // No Places key configured: hand off to Google Maps itself.
      const url = area
        ? `https://www.google.com/maps/search/${encodeURIComponent(kindWord() + " in " + area)}`
        : `https://www.google.com/maps/search/${encodeURIComponent(kindWord())}/@${origin.lat},${origin.lng},14z`;
      listEl.innerHTML = `<div class="empty-state"><div class="empty-ic">${icon("i-pin")}</div>
        <h3>Open ${esc(kindWord())} in Google Maps</h3>
        <p>In-app results will appear here once the site owner adds a Google Places API key.</p>
        <p><a class="btn btn-primary" href="${url}" target="_blank" rel="noopener">Open Google Maps</a></p></div>`;
      setStatus("");
      return;
    }

    const params = new URLSearchParams({ kind });
    if (area) params.set("q", area);
    else { params.set("lat", origin.lat); params.set("lng", origin.lng); params.set("radius", radiusEl ? radiusEl.value : "5000"); }

    skeleton();
    setStatus("Searching…");
    try {
      const res = await fetch(`${API}?${params}`, { headers: { Accept: "application/json" }, credentials: "same-origin" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Search failed.");
      showList(data.results);
      setStatus(data.results.length ? `${data.results.length} ${kindWord()} found${area ? ` in ${area}` : " near you"}.` : "");
      drawMap(data.results);
    } catch (err) {
      listEl.innerHTML = "";
      setStatus(err.message, true);
      mapEl.hidden = true;
    }
  }

  function locate() {
    if (!navigator.geolocation) { setStatus("Your browser can't share its location. Type an area instead.", true); return; }
    setStatus("Finding your location…");
    locBtn.disabled = true;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        locBtn.disabled = false;
        origin = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        area = ""; areaInput.value = "";
        run();
      },
      (err) => {
        locBtn.disabled = false;
        setStatus(err.code === 1
          ? "Location permission was denied. Allow it in your browser, or type an area instead."
          : "Couldn't get your location. Type an area instead.", true);
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 }
    );
  }

  // ---------------------------------------------------------- events
  locBtn.addEventListener("click", locate);
  areaForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = areaInput.value.trim();
    if (!q) return;
    area = q; origin = null;
    run();
  });
  tabs.forEach((t) => t.addEventListener("click", () => {
    kind = t.dataset.kind;
    tabs.forEach((x) => { const on = x === t; x.classList.toggle("active", on); x.setAttribute("aria-selected", on); });
    run();
  }));
  radiusEl?.addEventListener("change", run);

  // If the browser already has permission, start straight away.
  if (navigator.permissions) {
    navigator.permissions.query({ name: "geolocation" }).then((r) => { if (r.state === "granted") locate(); }).catch(() => {});
  }
})();
