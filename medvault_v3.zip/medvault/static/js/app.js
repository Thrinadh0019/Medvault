// Filter a report list as you type
document.querySelectorAll("[data-filter]").forEach((input) => {
  const list = document.querySelector(input.dataset.filter);
  if (!list) return;
  const counter = document.querySelector(`[data-count-for="${input.dataset.filter}"]`);
  const none = list.querySelector("[data-no-match]");
  const apply = () => {
    const q = input.value.trim().toLowerCase();
    let shown = 0;
    list.querySelectorAll(".file").forEach((li) => {
      const hit = !q || li.dataset.search.includes(q);
      li.classList.toggle("hidden", !hit);
      if (hit) shown++;
    });
    list.querySelectorAll(".month").forEach((m) =>
      m.classList.toggle("hidden", !m.querySelector(".file:not(.hidden)")));
    if (counter) counter.textContent = `${shown} report${shown === 1 ? "" : "s"}`;
    if (none) none.classList.toggle("hidden", shown !== 0);
  };
  input.addEventListener("input", apply);
});

// Drag & drop file zone
document.querySelectorAll("[data-dropzone]").forEach((zone) => {
  const input = zone.querySelector("input[type=file]");
  const title = zone.querySelector("[data-dz-title]");
  const show = () => {
    const f = input.files[0];
    if (f) {
      title.textContent = `${f.name} (${(f.size / 1024 / 1024).toFixed(2)} MB)`;
      zone.classList.add("has-file");
    }
  };
  input.addEventListener("change", show);
  ["dragenter", "dragover"].forEach((e) =>
    zone.addEventListener(e, (ev) => { ev.preventDefault(); zone.classList.add("drag"); }));
  ["dragleave", "drop"].forEach((e) =>
    zone.addEventListener(e, () => zone.classList.remove("drag")));
  zone.addEventListener("drop", (ev) => {
    ev.preventDefault();
    if (ev.dataTransfer.files.length) { input.files = ev.dataTransfer.files; show(); }
  });
});
