// Monthly / yearly price toggle on the plans page
document.querySelectorAll("[data-cycle-toggle]").forEach((toggle) => {
  const fmt = new Intl.NumberFormat("en-IN");
  const apply = (cycle) => {
    document.querySelectorAll(".plan-card").forEach((card) => {
      const paise = Number(card.dataset[cycle]);
      const price = card.querySelector("[data-price]");
      if (price) {
        price.textContent = "₹" + fmt.format(paise / 100);
        card.querySelector("[data-per]").textContent = cycle === "yearly" ? "/year" : "/month";
      }
      const input = card.querySelector("[data-cycle-input]");
      if (input) input.value = cycle;
    });
  };
  toggle.addEventListener("change", (e) => apply(e.target.value));
});

// Razorpay Checkout
const rzpBtn = document.getElementById("rzp-btn");
if (rzpBtn && window.Razorpay) {
  rzpBtn.addEventListener("click", () => {
    const d = rzpBtn.dataset;
    const rzp = new Razorpay({
      key: d.key, amount: Number(d.amount), currency: "INR", name: "MedVault",
      description: d.desc, order_id: d.order,
      prefill: { name: d.name, contact: d.contact },
      theme: { color: "#0e5a52" },
      handler: (r) => {
        document.getElementById("rzp-pay").value = r.razorpay_payment_id;
        document.getElementById("rzp-sig").value = r.razorpay_signature;
        document.getElementById("rzp-form").submit();
      },
    });
    rzp.open();
  });
}
