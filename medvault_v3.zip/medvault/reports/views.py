import mimetypes
from datetime import timedelta

from django.contrib import messages
from django.core.exceptions import ValidationError
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from accounts.decorators import doctor_required, patient_required
from accounts.models import User
from accounts.utils import normalize_phone
from billing.services import get_plan, usage

from .forms import ReportUploadForm
from .models import AccessLog, Report


def _patient_allows_lookup(phone):
    """Unregistered numbers can be looked up; registered patients can opt out."""
    patient = User.objects.filter(phone=phone, role=User.PATIENT).first()
    return patient is None or patient.allow_doctor_lookup


# ----------------------------------------------------------------- patient
@patient_required
def patient_dashboard(request):
    reports = list(Report.objects.filter(patient_phone=request.user.phone))
    sources = {r.uploader_name for r in reports if r.uploader_name}
    return render(request, "reports/patient_dashboard.html", {
        "reports": reports,
        "total": len(reports),
        "latest": reports[0].uploaded_at if reports else None,
        "source_count": len(sources),
        "access_logs": list(AccessLog.objects.filter(patient_phone=request.user.phone)[:8]),
    })


@patient_required
@require_POST
def patient_privacy(request):
    u = request.user
    u.allow_doctor_lookup = not u.allow_doctor_lookup
    u.save(update_fields=["allow_doctor_lookup"])
    messages.success(
        request,
        "Doctors can look up your reports." if u.allow_doctor_lookup
        else "Doctor look-ups are switched off. Only you can see your reports now.",
    )
    return redirect("patient_dashboard")


# ------------------------------------------------------------------ doctor
@doctor_required
def doctor_lookup(request):
    """Doctor enters a patient's mobile number and sees ALL of that patient's reports."""
    raw = request.GET.get("phone", "").strip()
    ctx = {"query": raw, "searched": bool(raw)}
    if raw:
        phone = normalize_phone(raw)
        if len(phone) != 10:
            ctx["error"] = "Enter a valid 10-digit mobile number."
        elif not request.user.is_verified:
            ctx["error"] = "Your account is awaiting verification, so patient look-ups are disabled."
        elif not _patient_allows_lookup(phone):
            ctx.update(phone=phone, blocked=True)
        else:
            user = request.user
            plan = get_plan(user)
            repeat = AccessLog.objects.filter(
                doctor=user, patient_phone=phone, viewed_at__gte=timezone.now() - timedelta(minutes=10)
            ).exists()   # refreshing the page within 10 min is not a new look-up
            u = usage(user, plan)
            if not repeat and plan.lookups is not None and u["lookups_used"] >= plan.lookups:
                ctx.update(phone=phone, limit_reached=True)
            else:
                reports = list(Report.objects.filter(patient_phone=phone))
                patient = User.objects.filter(phone=phone, role=User.PATIENT).first()
                if not repeat:
                    AccessLog.objects.create(
                        patient_phone=phone, doctor=user,
                        doctor_name=user.display_name, doctor_org=user.organization,
                        report_count=len(reports),
                    )
                    u = usage(user, plan)
                ctx.update(phone=phone, reports=reports, patient=patient, total=len(reports))
            ctx["usage"] = u
    return render(request, "reports/doctor_lookup.html", ctx)


@doctor_required
def doctor_dashboard(request):
    """Upload page (plan limits apply)."""
    user = request.user
    plan = get_plan(user)
    initial = {"patient_phone": request.GET.get("phone", "")}
    form = ReportUploadForm(request.POST or None, request.FILES or None, initial=initial, max_files=plan.max_files)
    limit_hit = False

    if request.method == "POST":
        if not user.is_verified:
            messages.error(request, "Your account is awaiting verification. You cannot upload yet.")
        elif form.is_valid():
            files = form.cleaned_data["files"]
            used = usage(user, plan)["uploads_used"]
            if plan.uploads is not None and used + len(files) > plan.uploads:
                limit_hit = True
            else:
                for f in files:
                    Report.objects.create(
                        patient_phone=form.cleaned_data["patient_phone"],
                        file=f, original_name=f.name[:255], note=form.cleaned_data["note"],
                        uploaded_by=user, uploader_name=user.first_name,
                        uploader_org=user.organization, uploader_badge=plan.badge,
                    )
                n = len(files)
                messages.success(request, f"Uploaded {n} file{'s' if n > 1 else ''} for {form.cleaned_data['patient_phone']}.")
                return redirect("doctor_dashboard")

    reports = list(Report.objects.filter(uploaded_by=user)[:25])
    return render(request, "reports/doctor_dashboard.html", {
        "form": form, "reports": reports, "usage": usage(user, plan), "limit_hit": limit_hit,
    })


# --------------------------------------------------------------- file access
def download_report(request, pk):
    """Patient (matching phone), the uploader, or a verified doctor (if the
    patient allows look-ups) may open a report."""
    if not request.user.is_authenticated:
        return redirect("home")
    try:
        report = get_object_or_404(Report, pk=pk)
    except (ValidationError, ValueError):
        raise Http404()
    u = request.user
    allowed = (
        (u.role == User.PATIENT and u.phone == report.patient_phone)
        or (u.role == User.DOCTOR and report.uploaded_by_id == u.pk)
        or (u.role == User.DOCTOR and u.is_verified and _patient_allows_lookup(report.patient_phone))
        or u.is_superuser
    )
    if not allowed:
        raise Http404()
    ctype = mimetypes.guess_type(report.original_name)[0] or "application/octet-stream"
    response = FileResponse(report.file.open("rb"), content_type=ctype)
    disposition = "attachment" if request.GET.get("download") else "inline"
    response["Content-Disposition"] = f'{disposition}; filename="{report.original_name}"'
    response["X-Content-Type-Options"] = "nosniff"
    return response
