from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TransactionTestCase, override_settings
import tempfile

from accounts.models import User
from reports.models import Report

TMP = tempfile.mkdtemp()


@override_settings(MEDIA_ROOT=TMP)
class FlowTests(TransactionTestCase):
    def setUp(self):
        self.doc = User.objects.create_user("9000000001", "pass12345X", role="doctor",
                                            first_name="Dr A", is_verified=True)
        self.p1 = User.objects.create_user("9876543210", "pass12345X", first_name="Pat One")
        self.p2 = User.objects.create_user("9111111111", "pass12345X", first_name="Pat Two")

    def test_upload_visible_only_to_that_phone(self):
        self.client.post("/doctor/login/", {"phone": "9000000001", "password": "pass12345X"})
        r = self.client.post("/doctor/upload/", {
            "patient_phone": "+91 98765-43210",
            "files": SimpleUploadedFile("blood_test.pdf", b"%PDF-1.4 x", content_type="application/pdf"),
        })
        self.assertEqual(r.status_code, 302)
        rep = Report.objects.get()
        self.assertEqual(rep.patient_phone, "9876543210")
        self.client.post("/logout/")

        self.client.post("/patient/login/", {"phone": "9876543210", "password": "pass12345X"})
        page = self.client.get("/patient/reports/").content.decode()
        self.assertIn("blood_test.pdf", page)
        self.assertEqual(self.client.get(f"/reports/{rep.pk}/file/").status_code, 200)
        self.client.post("/logout/")

        self.client.post("/patient/login/", {"phone": "9111111111", "password": "pass12345X"})
        self.assertNotIn("blood_test.pdf", self.client.get("/patient/reports/").content.decode())
        self.assertEqual(self.client.get(f"/reports/{rep.pk}/file/").status_code, 404)

    def test_role_separation_and_bad_file(self):
        # patient cannot use doctor login
        r = self.client.post("/doctor/login/", {"phone": "9876543210", "password": "pass12345X"})
        self.assertContains(r, "incorrect")
        self.client.post("/doctor/login/", {"phone": "9000000001", "password": "pass12345X"})
        r = self.client.post("/doctor/upload/", {
            "patient_phone": "9876543210",
            "files": SimpleUploadedFile("evil.exe", b"MZ")})
        self.assertContains(r, "unsupported file type")
        self.assertEqual(Report.objects.count(), 0)


@override_settings(MEDIA_ROOT=TMP)
class DoctorLookupTests(TransactionTestCase):
    def setUp(self):
        self.lab = User.objects.create_user("9000000001", "pass12345X", role="doctor",
                                            first_name="City Lab", organization="City Diagnostics", is_verified=True)
        self.doc = User.objects.create_user("9000000002", "pass12345X", role="doctor",
                                            first_name="Dr Rao", organization="Apollo", is_verified=True)
        self.newdoc = User.objects.create_user("9000000003", "pass12345X", role="doctor",
                                               first_name="Dr New", is_verified=False)
        self.pat = User.objects.create_user("9876543210", "pass12345X", first_name="Asha")

    def _login(self, phone, role="doctor"):
        self.client.post("/logout/")
        self.client.post(f"/{role}/login/", {"phone": phone, "password": "pass12345X"})

    def _upload(self, name):
        self.client.post("/doctor/upload/", {
            "patient_phone": "9876543210",
            "files": SimpleUploadedFile(name, b"%PDF-1.4 x", content_type="application/pdf")})

    def test_doctor_sees_all_reports_from_all_uploaders_and_is_logged(self):
        self._login("9000000001"); self._upload("cbc.pdf")
        self._login("9000000002"); self._upload("xray.pdf")
        page = self.client.get("/doctor/patients/", {"phone": "98765 43210"}).content.decode()
        self.assertIn("cbc.pdf", page); self.assertIn("xray.pdf", page); self.assertIn("Asha", page)
        # doctor can open a report uploaded by another clinician
        other = Report.objects.get(original_name="cbc.pdf")
        self.assertEqual(self.client.get(f"/reports/{other.pk}/file/").status_code, 200)
        # patient sees who looked
        self._login("9876543210", "patient")
        dash = self.client.get("/patient/reports/").content.decode()
        self.assertIn("Dr Rao", dash)

    def test_unverified_doctor_and_opt_out(self):
        self._login("9000000001"); self._upload("cbc.pdf")
        rep = Report.objects.get()
        self._login("9000000003")
        self.assertContains(self.client.get("/doctor/patients/", {"phone": "9876543210"}), "awaiting verification")
        self.assertEqual(self.client.get(f"/reports/{rep.pk}/file/").status_code, 404)
        # patient switches look-ups off
        self._login("9876543210", "patient")
        self.client.post("/patient/privacy/")
        self._login("9000000002")
        self.assertContains(self.client.get("/doctor/patients/", {"phone": "9876543210"}), "turned off look-ups")
        self.assertEqual(self.client.get(f"/reports/{rep.pk}/file/").status_code, 404)

    def test_all_pages_render(self):
        for url in ["/", "/patient/login/", "/patient/register/", "/doctor/login/", "/doctor/register/"]:
            self.assertEqual(self.client.get(url).status_code, 200, url)
        self._login("9000000002")
        for url in ["/doctor/patients/", "/doctor/patients/?phone=1", "/doctor/patients/?phone=9111111111", "/doctor/upload/?phone=9876543210"]:
            self.assertEqual(self.client.get(url).status_code, 200, url)
        self._login("9876543210", "patient")
        self.assertEqual(self.client.get("/patient/reports/").status_code, 200)
