from django.contrib import admin

from .models import AccessLog, Report


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ("original_name", "patient_phone", "uploader_name", "uploaded_at")
    search_fields = ("patient_phone", "original_name")


@admin.register(AccessLog)
class AccessLogAdmin(admin.ModelAdmin):
    list_display = ("patient_phone", "doctor_name", "doctor_org", "report_count", "viewed_at")
    search_fields = ("patient_phone", "doctor_name")
