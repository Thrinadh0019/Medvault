import os

from django import forms
from django.conf import settings

from accounts.utils import normalize_phone


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("widget", MultipleFileInput())
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        single = super().clean
        if isinstance(data, (list, tuple)):
            if not data:
                return single(None, initial)   # raises "required"
            return [single(d, initial) for d in data]
        return [single(data, initial)]


class ReportUploadForm(forms.Form):
    patient_phone = forms.CharField(
        label="Patient phone number", max_length=20,
        widget=forms.TextInput(attrs={"placeholder": "98765 43210", "inputmode": "tel", "autocomplete": "tel"}),
    )
    files = MultipleFileField(label="Report file")
    note = forms.CharField(
        label="Note (optional)", max_length=255, required=False,
        widget=forms.TextInput(attrs={"placeholder": "e.g. Fasting sample, repeat test"}),
    )

    def __init__(self, *args, max_files=1, **kwargs):
        super().__init__(*args, **kwargs)
        self.max_files = max_files
        if max_files > 1:
            self.fields["files"].label = f"Report files (up to {max_files})"
        else:
            # Single-file plans: the browser picker has no multi-select, but the server still reads
            # every posted file so extra files are rejected instead of silently dropped.
            widget = MultipleFileInput()
            widget.attrs.pop("multiple", None)
            widget.is_required = True
            self.fields["files"].widget = widget

    def clean_patient_phone(self):
        phone = normalize_phone(self.cleaned_data["patient_phone"])
        if len(phone) != 10:
            raise forms.ValidationError("Enter a valid 10-digit phone number.")
        return phone

    def clean_files(self):
        files = self.cleaned_data["files"]
        if len(files) > self.max_files:
            raise forms.ValidationError(
                f"Your plan allows {self.max_files} file{'s' if self.max_files > 1 else ''} per upload. Upgrade to upload more at once."
            )
        for f in files:
            ext = os.path.splitext(f.name)[1].lower()
            if ext not in settings.ALLOWED_REPORT_EXTENSIONS:
                allowed = ", ".join(settings.ALLOWED_REPORT_EXTENSIONS)
                raise forms.ValidationError(f"{f.name}: unsupported file type. Allowed: {allowed}")
            if f.size > settings.MAX_REPORT_SIZE_MB * 1024 * 1024:
                raise forms.ValidationError(f"{f.name} is larger than {settings.MAX_REPORT_SIZE_MB} MB.")
        return files
