import os
import uuid

from django.conf import settings
from django.db import models


def report_upload_path(instance, filename):
    # Random file name so files can't be guessed; original name kept separately.
    ext = os.path.splitext(filename)[1].lower()
    return f"reports/{instance.patient_phone}/{uuid.uuid4().hex}{ext}"


class Report(models.Model):
    # Linked by PHONE NUMBER (not by user) so a report uploaded before the
    # patient has signed up still appears as soon as they register.
    patient_phone = models.CharField(max_length=10, db_index=True)
    file = models.FileField(upload_to=report_upload_path)
    original_name = models.CharField(max_length=255)
    note = models.CharField(max_length=255, blank=True)
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="uploaded_reports"
    )
    # Copied from the uploader at upload time so listing reports needs no join.
    uploader_name = models.CharField(max_length=150, blank=True)
    uploader_org = models.CharField(max_length=120, blank=True)
    uploader_badge = models.CharField(max_length=20, blank=True)  # plan badge at upload time (Pro / Business)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-uploaded_at"]

    @property
    def ext(self):
        e = os.path.splitext(self.original_name)[1].lower().lstrip(".")
        return {"jpeg": "jpg"}.get(e, e).upper() or "FILE"

    def __str__(self):
        return f"{self.original_name} -> {self.patient_phone}"

    @property
    def file_kind(self):
        ext = os.path.splitext(self.original_name)[1].lower().lstrip(".")
        return "JPG" if ext == "jpeg" else (ext.upper() or "FILE")


class AccessLog(models.Model):
    """Every time a doctor looks up a patient's reports, it's recorded here
    and shown to the patient (transparency / audit trail)."""
    patient_phone = models.CharField(max_length=10, db_index=True)
    doctor = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="lookups"
    )
    doctor_name = models.CharField(max_length=150)
    doctor_org = models.CharField(max_length=120, blank=True)
    report_count = models.PositiveIntegerField(default=0)
    viewed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-viewed_at"]
