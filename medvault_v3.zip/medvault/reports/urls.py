from django.urls import path

from . import views

urlpatterns = [
    path("patient/reports/", views.patient_dashboard, name="patient_dashboard"),
    path("patient/privacy/", views.patient_privacy, name="patient_privacy"),
    path("doctor/patients/", views.doctor_lookup, name="doctor_lookup"),
    path("doctor/upload/", views.doctor_dashboard, name="doctor_dashboard"),
    path("reports/<str:pk>/file/", views.download_report, name="download_report"),
]
